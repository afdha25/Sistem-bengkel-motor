public class ServisRutin implements LayananBengkel {
    @Override
    public double hitungBiayaJasa() {
        return 75000;
    }
    @Override
    public String getDeskripsiLayanan() {
        return "Servis Ringan & Pembersihan Umum";
    }
}