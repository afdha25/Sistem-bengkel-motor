public class ServisBesar implements LayananBengkel {
    @Override
    public double hitungBiayaJasa() {

        return 200000;
    }
    @Override
    public String getDeskripsiLayanan() {
        return "Bongkar Mesin & Kalibrasi Menyeluruh";
    }

}