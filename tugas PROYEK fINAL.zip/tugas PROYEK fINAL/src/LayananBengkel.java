public interface LayananBengkel {
    double hitungBiayaJasa();
    String getDeskripsiLayanan();
}