public class ServisRutin implements LayananBengkel {
    @Override
    public String getDeskripsiLayanan() {
        return "Servis Ringan & Pembersihan Umum";
    }
}
