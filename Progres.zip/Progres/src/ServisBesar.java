public class ServisBesar implements LayananBengkel {
    @Override
    public String getDeskripsiLayanan() {
        return "Bongkar Mesin & Kalibrasi Menyeluruh";
    }

}