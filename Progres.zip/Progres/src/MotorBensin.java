public class MotorBensin extends Kendaraan {

    public MotorBensin(String platNomor, String merk, String pemilik) {
        super(platNomor, merk, pemilik);
    }

    @Override
    public String getJenisEnergi() {
        return "(Bensin)";
    }

}