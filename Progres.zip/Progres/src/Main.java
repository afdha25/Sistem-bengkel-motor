import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("=== BENGKEL MOTOR ===");
        System.out.print("Masukkan Nama Pemilik: ");
        String pemilik = scanner.nextLine();
        System.out.print("Masukkan Plat Nomor: ");
        String plat = scanner.nextLine();
        System.out.print("Masukkan Merk/Model: ");
        String merk = scanner.nextLine();

        System.out.println("Pilih Jenis Kendaraan (1. Bensin): ");
        int pilihanMotor = scanner.nextInt();
        Kendaraan knd = (pilihanMotor == 1) ? new MotorBensin(plat, merk, pemilik) : null;

        System.out.println("\nPilih Layanan (1. Rutin / 2. Besar): ");
        int pilihanLayanan = scanner.nextInt();
        LayananBengkel lyn = (pilihanLayanan == 1) ? new ServisRutin() : new ServisBesar();


        System.out.println("Terima kasih telah menggunakan layanan Kami.");
    }
}