public interface LayananBengkel {
    String getDeskripsiLayanan();
}